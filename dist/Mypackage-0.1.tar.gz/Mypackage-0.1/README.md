# mypackage

This library was created as an example of how publish your own Python package.

# How to install
